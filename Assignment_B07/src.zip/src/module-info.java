module assignment_B07 {
	requires org.junit.jupiter.api;
}